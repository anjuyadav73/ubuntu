"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'alertSettings';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'alert_settings';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnYWxlcnRTZXR0aW5ncyc7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnYWxlcnRfc2V0dGluZ3MnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsZUFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLGdCQUFwQiJ9