"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "AppSettingsPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.AppSettingsPluginSetup;
  }
});
Object.defineProperty(exports, "AppSettingsPluginStart", {
  enumerable: true,
  get: function () {
    return _types.AppSettingsPluginStart;
  }
});
exports.plugin = plugin;

var _plugin = require("./plugin");

var _types = require("./types");

//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.AppSettingsPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJwbHVnaW4iLCJpbml0aWFsaXplckNvbnRleHQiLCJBcHBTZXR0aW5nc1BsdWdpbiJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCB9IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBBcHBTZXR0aW5nc1BsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuLy8gIFRoaXMgZXhwb3J0cyBzdGF0aWMgY29kZSBhbmQgVHlwZVNjcmlwdCB0eXBlcyxcbi8vICBhcyB3ZWxsIGFzLCBLaWJhbmEgUGxhdGZvcm0gYHBsdWdpbigpYCBpbml0aWFsaXplci5cblxuZXhwb3J0IGZ1bmN0aW9uIHBsdWdpbihpbml0aWFsaXplckNvbnRleHQ6IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCkge1xuICByZXR1cm4gbmV3IEFwcFNldHRpbmdzUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7IEFwcFNldHRpbmdzUGx1Z2luU2V0dXAsIEFwcFNldHRpbmdzUGx1Z2luU3RhcnQgfSBmcm9tICcuL3R5cGVzJztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBOztBQVNBOztBQVBBO0FBQ0E7QUFFTyxTQUFTQSxNQUFULENBQWdCQyxrQkFBaEIsRUFBOEQ7RUFDbkUsT0FBTyxJQUFJQyx5QkFBSixDQUFzQkQsa0JBQXRCLENBQVA7QUFDRCJ9