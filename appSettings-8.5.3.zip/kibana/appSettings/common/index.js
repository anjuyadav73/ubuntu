"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'appSettings';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'app_settings';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnYXBwU2V0dGluZ3MnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ2FwcF9zZXR0aW5ncyc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxhQUFsQjs7QUFDQSxNQUFNQyxXQUFXLEdBQUcsY0FBcEIifQ==