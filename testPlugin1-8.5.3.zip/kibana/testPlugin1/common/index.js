"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'testPlugin1';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'test_plugin1';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAndGVzdFBsdWdpbjEnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ3Rlc3RfcGx1Z2luMSc7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxhQUFsQjs7QUFDQSxNQUFNQyxXQUFXLEdBQUcsY0FBcEIifQ==